set epsilon = 1e-4
inject initial solution
run algorithm
